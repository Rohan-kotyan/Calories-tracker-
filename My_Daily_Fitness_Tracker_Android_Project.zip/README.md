# My Daily Fitness Tracker — Android APK project

This project packages the supplied HTML tracker as an Android app using Capacitor. The included GitHub Actions workflow builds a **debug APK** automatically.

## Build the APK using GitHub (Android phone is okay)

1. Download and extract this ZIP.
2. Open https://github.com and create a **new repository** (for example `daily-fitness-tracker`). You can keep it Private.
3. Upload the *contents* of this extracted folder to the repository root. Ensure `package.json`, `capacitor.config.json`, `www/`, and `.github/workflows/build-apk.yml` are at the root—not inside another nested folder.
4. Commit the files to the `main` branch.
5. Open the repository → **Actions**.
6. Select **Build Android APK** on the left. If GitHub asks, enable Actions.
7. If it doesn't start automatically after the upload, press **Run workflow** → **Run workflow**.
8. Wait for the workflow to finish with a green check.
9. Open that completed workflow run, scroll to **Artifacts**, and tap `Daily-Fitness-Tracker-debug-APK` to download the ZIP artifact.
10. Extract the downloaded artifact ZIP. Inside is `app-debug.apk`.
11. Open `app-debug.apk` on your Android phone and allow installation from that source if Android asks.

## Important notes

- This produces a **debug APK for testing**, not a Play Store-ready signed release and not an AAB.
- The package ID is `com.stellixstudios.dailyfitnesstracker`. Choose your final ID before publishing; changing it later creates a different app identity.
- The food scanner requires your own Gemini API key. In the current HTML, the key is stored in browser local storage. Do not distribute a build with your personal key entered; client-side API keys can be extracted. For a public app, route Gemini requests through a backend and apply API restrictions.
- The HTML loads Tailwind, Font Awesome, and Google Fonts from online CDNs, so those visual resources need internet access.
- The app currently uses local storage and IndexedDB for data/photos. Treat app data as device-local; uninstalling the app or clearing its data may remove it. Export a backup regularly.
- Before Play Store release, test the app thoroughly, create a signed release build, prepare a privacy policy, and verify current Play Console requirements.
